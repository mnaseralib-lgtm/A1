// Basic Service Worker for caching shell files
const CACHE_NAME = 'smart-attendance-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(resp => resp || fetch(event.request).then(fetchRes => {
      return caches.open(CACHE_NAME).then(cache => { cache.put(event.request, fetchRes.clone()); return fetchRes; });
    })).catch(()=>caches.match('/'))
  );
});
